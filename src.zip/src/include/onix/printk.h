#ifndef ONIX_PRINTK_H
#define ONIX_PRINTK_H

int printk(const char *fmt, ...);

#endif