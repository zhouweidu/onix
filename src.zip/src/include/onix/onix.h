#ifndef ONIX_H
#define ONIX_H

#define ONIX_MAGIC 0x20220205

void kernel_init();

#endif